/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author nanet
 */
public class Propietario extends Persona{
    
    private String idCasa;
    private String oficio;
    private String profesion;

    public Propietario() {
    }

    public Propietario(String idCasa, String oficio, String profesion, String nombre, String telefono, String correo, String id) {
        super(nombre, telefono, correo, id);
        this.idCasa = idCasa;
        this.oficio = oficio;
        this.profesion = profesion;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public String getIdCasa() {
        return idCasa;
    }

    public void setIdCasa(String idCasa) {
        this.idCasa = idCasa;
    }

    public String getOficio() {
        return oficio;
    }

    public void setOficio(String oficio) {
        this.oficio = oficio;
    }

    @Override
    public String toString() {
        return "Propietario{" + "idCasa=" + idCasa + ", oficio=" + oficio + ", profesion=" + profesion + '}';
    }   
    
}
