/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


/**
 *
 * @author nanet
 */
public class Empleado extends Persona {
    private String cargo;
    private String fechaDeInicio;
    private String calificacion;
    private String salario;

    public Empleado() {
    }

    public Empleado(String cargo, String fechaDeInicio, String calificacion, String salario, String nombre, String telefono, String correo, String id) {
        super(nombre, telefono, correo, id);
        this.cargo = cargo;
        this.fechaDeInicio = fechaDeInicio;
        this.calificacion = calificacion;
        this.salario = salario;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getFechaDeInicio() {
        return fechaDeInicio;
    }

    public void setFechaDeInicio(String fechaDeInicio) {
        this.fechaDeInicio = fechaDeInicio;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    @Override
    public String toString() {
        return "Empleado{" + "cargo=" + cargo + ", fechaDeInicio=" + fechaDeInicio + ", calificacion=" + calificacion + ", salario=" + salario + '}';
    }
    
}
