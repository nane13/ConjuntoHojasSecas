/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author nanet
 */
public class Factura {
    private String numero;
    private String fechaEmision;
    private String idPropiedad;
    private String valorPagar;
    private String numeroCuentasVencidas;
    private String valorMulta;
    private String valorCuentasVencidas;
    private String descuento;
    private String otrosCargos;
    private String totalPagar;
    private String fechaMaxPago;
    private String infoPago;
    private String mensaje;
    private String valorPagado;

    public Factura() {
    }

    public Factura(String numero, String fechaEmision, String idPropiedad, String valorPagar, String numeroCuentasVencidas, String valorMulta, String valorCuentasVencidas, String descuento, String otrosCargos, String totalPagar, String fechaMaxPago, String infoPago, String mensaje, String valorPagado) {
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.idPropiedad = idPropiedad;        
        this.valorPagar = valorPagar;
        this.numeroCuentasVencidas = numeroCuentasVencidas;
        this.valorMulta = valorMulta;
        this.valorCuentasVencidas = valorCuentasVencidas;
        this.descuento = descuento;
        this.otrosCargos = otrosCargos;
        this.totalPagar = totalPagar;
        this.fechaMaxPago = fechaMaxPago;
        this.infoPago = infoPago;
        this.mensaje = mensaje;
        this.valorPagado = valorPagado;
    }

    public String getValorPagado() {
        return valorPagado;
    }

    public void setValorPagado(String valorPagado) {
        this.valorPagado = valorPagado;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(String idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public String getValorPagar() {
        return valorPagar;
    }

    public void setValorPagar(String valorPagar) {
        this.valorPagar = valorPagar;
    }

    public String getNumeroCuentasVencidas() {
        return numeroCuentasVencidas;
    }

    public void setNumeroCuentasVencidas(String numeroCuentasVencidas) {
        this.numeroCuentasVencidas = numeroCuentasVencidas;
    }

    public String getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(String valorMulta) {
        this.valorMulta = valorMulta;
    }

    public String getValorCuentasVencidas() {
        return valorCuentasVencidas;
    }

    public void setValorCuentasVencidas(String valorCuentasVencidas) {
        this.valorCuentasVencidas = valorCuentasVencidas;
    }

    public String getDescuento() {
        return descuento;
    }

    public void setDescuento(String descuento) {
        this.descuento = descuento;
    }

    public String getOtrosCargos() {
        return otrosCargos;
    }

    public void setOtrosCargos(String otrosCargos) {
        this.otrosCargos = otrosCargos;
    }

    public String getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(String totalPagar) {
        this.totalPagar = totalPagar;
    }

    public String getFechaMaxPago() {
        return fechaMaxPago;
    }

    public void setFechaMaxPago(String fechaMaxPago) {
        this.fechaMaxPago = fechaMaxPago;
    }

    public String getInfoPago() {
        return infoPago;
    }

    public void setInfoPago(String infoPago) {
        this.infoPago = infoPago;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String toString() {
        return "Factura{" + "numero=" + numero + ", fechaEmision=" + fechaEmision + ", idPropiedad=" + idPropiedad + ", valorPagar=" + valorPagar + ", numeroCuentasVencidas=" + numeroCuentasVencidas + ", valorMulta=" + valorMulta + ", valorCuentasVencidas=" + valorCuentasVencidas + ", descuento=" + descuento + ", otrosCargos=" + otrosCargos + ", totalPagar=" + totalPagar + ", fechaMaxPago=" + fechaMaxPago + ", infoPago=" + infoPago + ", mensaje=" + mensaje + ", valorPagado=" + valorPagado + '}';
    }
    
}
