/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author nanet
 */
public class ZonaComun extends Propiedad{
    private String descripcion;
    private String horaApertura;
    private String horaCierre;
    private String periocidadMantenimiento;
    private String costoMantenimiento;
    private String capacidadMax;
    private String diasDeServicio;

    public ZonaComun() {
    }

    public ZonaComun(String descripcion, String horaApertura, String horaCierre, String periocidadMantenimiento, String costoMantenimiento, String capacidadMax, String diasDeServicio, String estado, String identificacion, String tipo) {
        super(estado, identificacion, tipo);
        this.descripcion = descripcion;
        this.horaApertura = horaApertura;
        this.horaCierre = horaCierre;
        this.periocidadMantenimiento = periocidadMantenimiento;
        this.costoMantenimiento = costoMantenimiento;
        this.capacidadMax = capacidadMax;
        this.diasDeServicio = diasDeServicio;
    }

    public String getDiasDeServicio() {
        return diasDeServicio;
    }

    public void setDiasDeServicio(String diasDeServicio) {
        this.diasDeServicio = diasDeServicio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getHoraApertura() {
        return horaApertura;
    }

    public void setHoraApertura(String horaApertura) {
        this.horaApertura = horaApertura;
    }

    public String getHoraCierre() {
        return horaCierre;
    }

    public void setHoraCierre(String horaCierre) {
        this.horaCierre = horaCierre;
    }

    public String getPeriocidadMantenimiento() {
        return periocidadMantenimiento;
    }

    public void setPeriocidadMantenimiento(String periocidadMantenimiento) {
        this.periocidadMantenimiento = periocidadMantenimiento;
    }

    public String getCostoMantenimiento() {
        return costoMantenimiento;
    }

    public void setCostoMantenimiento(String costoMantenimiento) {
        this.costoMantenimiento = costoMantenimiento;
    }

    public String getCapacidadMax() {
        return capacidadMax;
    }

    public void setCapacidadMax(String capacidadMax) {
        this.capacidadMax = capacidadMax;
    }

    @Override
    public String toString() {
        return "ZonaComun{" + "descripcion=" + descripcion + ", horaApertura=" + horaApertura + ", horaCierre=" + horaCierre + ", periocidadMantenimiento=" + periocidadMantenimiento + ", costoMantenimiento=" + costoMantenimiento + ", capacidadMax=" + capacidadMax + ", diasDeServicio=" + diasDeServicio + '}';
    }
    
}
