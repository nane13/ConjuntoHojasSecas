/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author nanet
 */
public class Casa extends Propiedad{
    private String direccion;
    private String telefono;
    private String saldo;
    private String valorAdministracion;
    private String idPropietario;
    private String metrosCuadrados;

    public Casa() {
    }

    public Casa(String direccion, String telefono, String saldo, String valorAdministracion, String idPropietario, String metrosCuadrados, String estado, String identificacion, String tipo) {
        super(estado, identificacion, tipo);
        this.direccion = direccion;
        this.telefono = telefono;
        this.saldo = saldo;
        this.valorAdministracion = valorAdministracion;
        this.idPropietario = idPropietario;
        this.metrosCuadrados = metrosCuadrados;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getSaldo() {
        return saldo;
    }

    public void setSaldo(String saldo) {
        this.saldo = saldo;
    }

    public String getValorAdministracion() {
        return valorAdministracion;
    }

    public void setValorAdministracion(String valorAdministracion) {
        this.valorAdministracion = valorAdministracion;
    }

    public String getIdPropietario() {
        return idPropietario;
    }

    public void setIdPropietario(String idPropietario) {
        this.idPropietario = idPropietario;
    }

    public String getMetrosCuadrados() {
        return metrosCuadrados;
    }

    public void setMetrosCuadrados(String metrosCuadrados) {
        this.metrosCuadrados = metrosCuadrados;
    }

    @Override
    public String toString() {
        return "Casa{" + "direccion=" + direccion + ", telefono=" + telefono + ", saldo=" + saldo + ", valorAdministracion=" + valorAdministracion + ", idPropietario=" + idPropietario + ", metrosCuadrados=" + metrosCuadrados + '}';
    }
}
