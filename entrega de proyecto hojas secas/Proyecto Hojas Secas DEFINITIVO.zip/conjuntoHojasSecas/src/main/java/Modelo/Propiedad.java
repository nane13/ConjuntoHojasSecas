/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author nanet
 */
public class Propiedad {
    private String estado;
    private String identificacion;
    private String tipo;

    public Propiedad() {
    }
    
    public Propiedad(String estado, String identificacion, String tipo) {
        this.estado = estado;
        this.identificacion = identificacion;
        this.tipo = tipo;
    }   

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Propiedad{" + ", estado=" + estado + ", identificacion=" + identificacion + ", tipo=" + tipo + '}';
    }
    
}
            
        

