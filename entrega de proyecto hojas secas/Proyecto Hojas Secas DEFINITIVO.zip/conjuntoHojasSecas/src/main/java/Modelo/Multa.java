/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
/**
 *
 * @author nanet
 */
public class Multa {
    private String identificacion;
    private String fechaEmision;
    private String fechaEventoMulta;
    private String idPropiedad;
    private String personaMultada;
    private String descripcionEvento;
    private String evento;
    private String valorMulta;
    private String fechaMaxPago;
    private String observacion; 

    public Multa() {
    }

    public Multa(String identificacion, String fechaEmision, String fechaEventoMulta, String idPropiedad, String personaMultada, String descripcionEvento, String evento, String valorMulta, String fechaMaxPago, String observacion) {
        this.identificacion = identificacion;
        this.fechaEmision = fechaEmision;
        this.fechaEventoMulta = fechaEventoMulta;
        this.idPropiedad = idPropiedad;
        this.personaMultada = personaMultada;
        this.descripcionEvento = descripcionEvento;
        this.evento = evento;
        this.valorMulta = valorMulta;
        this.fechaMaxPago = fechaMaxPago;
        this.observacion = observacion;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getFechaEventoMulta() {
        return fechaEventoMulta;
    }

    public void setFechaEventoMulta(String fechaEventoMulta) {
        this.fechaEventoMulta = fechaEventoMulta;
    }

    public String getPropiedad() {
        return idPropiedad;
    }

    public void setPropiedad(String idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public String getPersonaMultada() {
        return personaMultada;
    }

    public void setPersonaMultada(String personaMultada) {
        this.personaMultada = personaMultada;
    }

    public String getDescripcionEvento() {
        return descripcionEvento;
    }

    public void setDescripcionEvento(String descripcionEvento) {
        this.descripcionEvento = descripcionEvento;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(String valorMulta) {
        this.valorMulta = valorMulta;
    }

    public String getFechaMaxPago() {
        return fechaMaxPago;
    }

    public void setFechaMaxPago(String fechaMaxPago) {
        this.fechaMaxPago = fechaMaxPago;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    @Override
    public String toString() {
        return "Multa{" + "identificacion=" + identificacion + ", fechaEmision=" + fechaEmision + ", fechaEventoMulta=" + fechaEventoMulta + ", idPropiedad=" + idPropiedad + ", personaMultada=" + personaMultada + ", descripcionEvento=" + descripcionEvento + ", evento=" + evento + ", valorMulta=" + valorMulta + ", fechaMaxPago=" + fechaMaxPago + ", observacion=" + observacion + '}';
    }
    
}
