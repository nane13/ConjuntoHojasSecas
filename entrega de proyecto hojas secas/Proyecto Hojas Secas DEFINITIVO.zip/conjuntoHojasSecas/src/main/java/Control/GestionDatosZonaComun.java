/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import Modelo.ZonaComun;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author nanet
 */
public class GestionDatosZonaComun {
    
    public void registrarZonaComun() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
    // Método para leer los datos y guardarlos en un archivo CSV
    public void registrarZonaComun(String descripcion, String horaApertura, String horaCierre, String periocidadMantenimiento, String costoMantenimiento, String capacidadMax, String diasDeServicio, String estado, String identificacion, String tipo) throws Exception {

        // Crear el archivo CSV
        try (FileWriter csvWriter = new FileWriter("zonasComunesHojasSecas.csv", true)) {
            csvWriter.append(descripcion);
            csvWriter.append(";");
            csvWriter.append(String.valueOf(horaApertura));
            csvWriter.append(";");
            csvWriter.append(String.valueOf(horaCierre));
            csvWriter.append(";");
            csvWriter.append(String.valueOf(periocidadMantenimiento));
            csvWriter.append(";");
            csvWriter.append(String.valueOf(costoMantenimiento));
            csvWriter.append(";");
            csvWriter.append(String.valueOf(capacidadMax));
            csvWriter.append(";");
            String diasDeServicioStr = String.join(",", diasDeServicio);
            csvWriter.append(diasDeServicioStr);
            csvWriter.append(";");
            csvWriter.append(estado);
            csvWriter.append(";");
            csvWriter.append(identificacion);
            csvWriter.append(";");
            csvWriter.append(tipo);
            csvWriter.append("\n");
            csvWriter.flush();
        } catch (IOException ex) {
            throw new Exception("Error al registrar la zona común.", ex);
        }
    }

    private List<ZonaComun> zonasComunes;

    public GestionDatosZonaComun() {
        zonasComunes = new ArrayList<>();  // Inicialización
    }

    // Método para leer el archivo CSV
    public List<ZonaComun> leerCSV(String rutaArchivo) {
   
        zonasComunes = new ArrayList<ZonaComun>();
        String linea;
        try (BufferedReader br = new BufferedReader(new FileReader("zonasComunesHojasSecas.csv"))) {
            br.readLine();
            while ((linea = br.readLine()) != null) {
                
                // Separar por punto y coma
                String[] valores = linea.split(";", -1);
                
                String descripcion = valores[0];
                String horaApertura = valores[1];
                String horaCierre = valores[2];
                String periocidadMantenimiento = valores[3];
                String costoMantenimiento = valores[4];
                String capacidadMax = valores[5];
                String diasDeServicio = valores[6];
                String estado = valores[7];  
                String identificacion = valores[8];
                String tipo = valores[9];

                ZonaComun zonaComun = new ZonaComun(descripcion, horaApertura, horaCierre, periocidadMantenimiento, costoMantenimiento, capacidadMax, diasDeServicio, estado, identificacion, tipo);
                // Agregar el zonaComun a la lista
                zonasComunes.add(zonaComun);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return zonasComunes;
    }

    public List<ZonaComun> getZonaComun() {
        return zonasComunes;
    }
    
    public ZonaComun buscarID(String id) {
        for (ZonaComun zonaComun : zonasComunes) {

            if (zonaComun.getIdentificacion().equals(id)) {
                return zonaComun;  // ZonaComun encontrado
            }
        }
        return null;  // ZonaComun no encontrado
    }
        
    public boolean actualizarZonaComun(String id, ZonaComun nuevosDatos) {
        
        boolean actualizado = false;
        
        for (ZonaComun zonaComun : zonasComunes) {
            if (zonaComun.getIdentificacion().equals(id)) {
                // Actualizar los atributos del zonaComun
                zonaComun.setDescripcion(nuevosDatos.getDescripcion());
                zonaComun.setHoraApertura(nuevosDatos.getHoraApertura());
                zonaComun.setHoraCierre(nuevosDatos.getHoraCierre());
                zonaComun.setPeriocidadMantenimiento(nuevosDatos.getPeriocidadMantenimiento());
                zonaComun.setCostoMantenimiento(nuevosDatos.getCostoMantenimiento());
                zonaComun.setCapacidadMax(nuevosDatos.getCapacidadMax());
                zonaComun.setDiasDeServicio(nuevosDatos.getDiasDeServicio());              
                zonaComun.setEstado(nuevosDatos.getEstado());
                zonaComun.setIdentificacion(nuevosDatos.getIdentificacion());
                zonaComun.setTipo(nuevosDatos.getTipo());
  
                actualizado = true;  // ZonaComun actualizado
            }
        }
        return actualizado;  // ZonaComun no encontrado
    }
    
    public void guardarEnCSV(String rutaArchivo) {
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            // Escribir encabezado (si es necesario)
            bw.write("Descripcion;HoraApertura;HoraCierre;PeriocidadMantenimiento;CostoMantenimiento;CapacidadMax;DiasDeServicio;Estado;Identificacion;Tipo\n");

            // Escribir los datos de cada zonaComun
            for (ZonaComun zonaComun : zonasComunes) {
                
                bw.write(String.join(";", 
                    zonaComun.getDescripcion(),
                    String.valueOf(zonaComun.getHoraApertura()),
                    String.valueOf(zonaComun.getHoraCierre()),
                    String.valueOf(zonaComun.getPeriocidadMantenimiento()),
                    String.valueOf(zonaComun.getCostoMantenimiento()),
                    String.valueOf(zonaComun.getCapacidadMax()),
                    zonaComun.getDiasDeServicio(),
                    zonaComun.getEstado(),
                    zonaComun.getIdentificacion(),
                    zonaComun.getTipo()) + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ZonaComun buscarConId(String id) {
  
        for (ZonaComun zonaComun : zonasComunes) {
            if(zonaComun.getIdentificacion().equals(id)){             
                return zonaComun;  // ZonaComun encontrado                
            }
        }return null;  // ZonaComun no encontrado
    }
    
    public void eliminarZonaComun(String id) {
       
        ZonaComun zonaComunAEliminar = buscarConId(id); // Buscar al zonaComun

        if (zonaComunAEliminar != null) {
            zonasComunes.remove(zonaComunAEliminar); // Eliminar el zonaComun encontrado

            guardarEnCSV("zonasComunesHojasSecas.csv"); // Guardar cambios en el archivo CSV
        }
    }    
}
