/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import Vista.MenuEmpleados;
import Vista.MenuPropietarios;
import javax.swing.JOptionPane;

/**
 *
 * @author nanet
 */
public class GestionDatos {
    
    public static String validarUsuario(String usuario, String contrasena) {
        
        if (usuario.equals("administrador") && contrasena.equals("administrador")) {
            return "Administrador";
        } else if (usuario.equals("propietario") && contrasena.equals("propietario")) {
            return "Propietario";
        } else if (usuario.equals("empleado") && contrasena.equals("empleado")) {
            return "Empleado";
        } else {
            return null;
        }
    }
    
    public void iniciarSesion(String usuario, String contrasena) {
        String rol = validarUsuario(usuario, contrasena);

        if (rol != null) {
            abrirVentanaPorRol(rol);
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void abrirVentanaPorRol(String rol) {
        switch (rol) {
            case "Administrador":
                new MenuEmpleados().setVisible(true);               
                break;
            case "Propietario":
                new MenuPropietarios().setVisible(true);              
                break;
            case "Empleado":
                new MenuEmpleados().setVisible(true);
                break;
        }
    }    
}
