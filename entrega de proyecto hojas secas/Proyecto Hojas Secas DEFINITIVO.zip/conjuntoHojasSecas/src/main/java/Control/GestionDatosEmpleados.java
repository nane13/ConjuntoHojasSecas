/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import Modelo.Empleado;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nanet
 */
public class GestionDatosEmpleados {
    
    public void registrarEmpleado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
    // Método para leer los datos y guardarlos en un archivo CSV
    public void registrarEmpleado(String cargo, String fechaDeInicio, String calificacion, String salario, String nombre, String telefono, String correo, String id) throws Exception {

        // Crear el archivo CSV
        try (FileWriter csvWriter = new FileWriter("empleadosHojasSecas.csv", true)) {
            csvWriter.append(cargo);
            csvWriter.append(";");
            csvWriter.append(fechaDeInicio);
            csvWriter.append(";");
            csvWriter.append(calificacion);
            csvWriter.append(";");
            csvWriter.append(salario);
            csvWriter.append(";");
            csvWriter.append(nombre);
            csvWriter.append(";");
            csvWriter.append(telefono);
            csvWriter.append(";");
            csvWriter.append(correo);
            csvWriter.append(";");
            csvWriter.append(id);
            csvWriter.append("\n");
            csvWriter.flush();
        } catch (IOException ex) {
            throw new Exception("Error al registrar el empleado.", ex);
        }
    }

    private List<Empleado> empleados;

    public GestionDatosEmpleados() {
        empleados = new ArrayList<>();  // Inicialización
    }

    // Método para leer el archivo CSV
    public List<Empleado> leerCSV(String rutaArchivo) {
       
        empleados = new ArrayList<Empleado>();
        String linea;
        try (BufferedReader br = new BufferedReader(new FileReader("empleadosHojasSecas.csv"))) {
            br.readLine();
            while ((linea = br.readLine()) != null) {
                
                // Separar por punto y coma
                String[] valores = linea.split(";", -1);
                
                String cargo = valores[0];
                String fechaDeInicio = valores[1];
                String calificacion = valores[2];
                String salario = valores[3];
                String nombre = valores[4];
                String telefono = valores[5];
                String correo = valores[6];
                String id = valores[7];          

                Empleado empleado = new Empleado(cargo, fechaDeInicio, calificacion, salario, nombre, telefono, correo, id);
                // Agregar el empleado a la lista
                empleados.add(empleado);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return empleados;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }
    
    public Empleado buscarID(String id) {
        for (Empleado empleado : empleados) {

            if (empleado.getId().equals(id)) {
                return empleado;  // Empleado encontrado
            }
        }
        return null;  // Empleado no encontrado
    }
        
    public boolean actualizarEmpleado(String id, Empleado nuevosDatos) {
        
        boolean actualizado = false;
        
        for (Empleado empleado : empleados) {
            if (empleado.getId().equals(id)) {
                // Actualizar los atributos del empleado
                empleado.setCargo(nuevosDatos.getCargo());
                empleado.setFechaDeInicio(nuevosDatos.getFechaDeInicio());
                empleado.setCalificacion(nuevosDatos.getCalificacion());
                empleado.setSalario(nuevosDatos.getSalario());
                empleado.setNombre(nuevosDatos.getNombre());
                empleado.setTelefono(nuevosDatos.getTelefono());
                empleado.setCorreo(nuevosDatos.getCorreo());              
                empleado.setId(nuevosDatos.getId());
  
                actualizado = true;  // Empleado actualizado
            }
        }
        return actualizado;  // Empleado no encontrado
    }
    
    public void guardarEnCSV(String rutaArchivo) {
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            // Escribir encabezado (si es necesario)
            bw.write("Cargo;FechaDeInicio;Calificacion;Salario;Nombre;Telefono;Correo;Id\n");

            // Escribir los datos de cada empleado
            for (Empleado empleado : empleados) {
                bw.write(String.join(";", 
                    empleado.getCargo(),
                    String.valueOf(empleado.getFechaDeInicio()),
                    String.valueOf(empleado.getCalificacion()),
                    String.valueOf(empleado.getSalario()),
                    empleado.getNombre(),
                    empleado.getTelefono(),
                    empleado.getCorreo(),
                    empleado.getId()) + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Empleado buscarConId(String id) {
  
        for (Empleado empleado : empleados) {
            if(empleado.getId().equals(id)){             
                return empleado;  // Empleado encontrado                
            }
        }return null;  // Empleado no encontrado
    }
    
    public void eliminarEmpleado(String id) {
       
        Empleado empleadoAEliminar = buscarConId(id); // Buscar al empleado

        if (empleadoAEliminar != null) {
            empleados.remove(empleadoAEliminar); // Eliminar el empleado encontrado

            guardarEnCSV("empleadosHojasSecas.csv"); // Guardar cambios en el archivo CSV
        }
    }
    
}
