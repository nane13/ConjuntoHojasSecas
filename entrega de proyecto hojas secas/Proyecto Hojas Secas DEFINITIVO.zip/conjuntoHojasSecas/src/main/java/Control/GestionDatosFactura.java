/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import Modelo.Factura;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Component;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author nanet
 */
public class GestionDatosFactura {
    private static GestionDatosFactura instancia;
    private final List<Factura> facturas;

    public GestionDatosFactura() {
        facturas = new ArrayList<>();
    }
    
    public static GestionDatosFactura getInstance() {
        if (instancia == null) {
            instancia = new GestionDatosFactura();
        }
        return instancia;
    }
    
    public void agregarFactura(Factura factura) {
        facturas.add(factura);
    }

    public Factura buscarPorId(String numero) {
        for (Factura factura : facturas) {
            if (factura.getNumero().equals(numero)) {
                return factura; // Factura encontrada
            }
        }
        return null; // Factura no encontrada
    }    
    
    public void crearPdf(Component parentComponent,String numero, String fechaEmision, String idPropiedad, String valorPagar, String numeroCuentasVencidas, String valorMulta, String valorCuentasVencidas, String descuento, String otrosCargos, String totalPagar, String fechaMaxPago, String infoPago, String mensaje, String valorPagado) { 
    // parentComponent permite obtener el index sobre cual se trabaja para manejar las ventanas emergentes de las excepciones desde el metodo
        Document doc = new Document(); //instanciamos un documento
        try {
            File archivoPDF = new File("Factura.pdf");
            if (archivoPDF.exists() && !archivoPDF.renameTo(archivoPDF)) {
                throw new IOException("El archivo ya está siendo utilizado por otro proceso.");
            }            
            
            Font tipo1 = FontFactory.getFont(BaseFont.TIMES_ROMAN, 20, BaseColor.BLACK);
            Font tipo2 = FontFactory.getFont(BaseFont.TIMES_ROMAN, 17, BaseColor.BLACK);
            Font tipo3 = FontFactory.getFont(BaseFont.TIMES_ROMAN, 15, BaseColor.BLACK);
            
            PdfWriter.getInstance(doc, new FileOutputStream("Factura.pdf")); //generamos el documento
            doc.open();

            Paragraph titulo = new Paragraph("FACTURA", tipo1);
            titulo.setAlignment(Element.ALIGN_CENTER); // metodo para centrar el parrafo
            titulo.setSpacingAfter(25f);  // metodo para espaciar entre parrafos
            doc.add(titulo);
            
            Paragraph subtitulo = new Paragraph("LA ADMINISTRACIÓN DEL CONJUNTO HOJAS SECAS", tipo2);
            subtitulo.setAlignment(Element.ALIGN_CENTER);
            subtitulo.setSpacingAfter(15f);  
            doc.add(subtitulo);
            
            Paragraph subtitulo2 = new Paragraph("GENERA LA SIGUIENTE FACTURA:", tipo2);
            subtitulo2.setAlignment(Element.ALIGN_CENTER);
            subtitulo2.setSpacingAfter(15f);  
            doc.add(subtitulo2);
            
            Paragraph cuerpo = new Paragraph("La factura de número "+numero+" emitida el "+fechaEmision+ " a la propiedad "+idPropiedad+", contiene las siguientes especificaciones: ", tipo3);
            cuerpo.setAlignment(Element.ALIGN_CENTER);  
            doc.add(cuerpo);
            
            Paragraph cuerpo2 = new Paragraph("Valor neto a pagar: "+valorPagar+" ------- Número de cuentas vencidas: "+numeroCuentasVencidas+ " ------- Valor cuentas vencidas: "+valorCuentasVencidas+" ------- Valor multa: "+ valorMulta+" ------- Descuento: "+descuento+ " ------- Otros cargos: "+otrosCargos+" ------- Total a pagar: "+ totalPagar+" ------- Fecha máxima de pago: "+fechaMaxPago+ " ------- Información de pago: "+infoPago+" ------- Valor pagado: "+ valorPagado,tipo3);
            cuerpo.setAlignment(Element.ALIGN_CENTER);  
            doc.add(cuerpo2);
            
            Paragraph cuerpo3 = new Paragraph("Mensaje: "+mensaje, tipo3);
            cuerpo.setAlignment(Element.ALIGN_CENTER);  
            doc.add(cuerpo3);
            
            doc.addAuthor("Factura");
            Factura factura = new Factura(numero, fechaEmision, idPropiedad, valorPagar, numeroCuentasVencidas, valorMulta, valorCuentasVencidas, descuento, otrosCargos, totalPagar, fechaMaxPago, infoPago, mensaje, valorPagado);
            
            agregarFactura(factura);
            
            JOptionPane.showMessageDialog(parentComponent, "¡Su factura fue generada y descargada con éxito!", "Factura", JOptionPane.INFORMATION_MESSAGE);
        } catch (DocumentException e) {
            //manejo de error con la creación del documento
            JOptionPane.showMessageDialog(parentComponent, "Error al crear el documento PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (IOException e) {
            //manejo de excepcion de archivo en uso
            JOptionPane.showMessageDialog(parentComponent, "Debes cerrar el PDF en tus otras aplicaciones para poder descargar uno nuevo.\nVuelve a presionar el botón de descargar cuando hayas cerrado el archivo PDF.", "Archivo en uso", JOptionPane.WARNING_MESSAGE);
            e.printStackTrace();
        } finally {
            if (doc.isOpen()) {
                doc.close();
            }
        }
    }    
}
