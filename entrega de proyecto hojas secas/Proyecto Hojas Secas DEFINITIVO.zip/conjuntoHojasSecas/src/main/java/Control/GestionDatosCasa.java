/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Casa;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nanet
 */
public class GestionDatosCasa {

    public void registrarCasa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
    // Método para leer los datos y guardarlos en un archivo CSV
    public void registrarCasa(String direccion, String telefono, String saldo, String valorAdministracion, String idPropietario, String metrosCuadrados, String estado, String identificacion, String tipo) throws Exception {

        // Crear el archivo CSV
        try (FileWriter csvWriter = new FileWriter("casasHojasSecas.csv", true)) {
            csvWriter.append(direccion);
            csvWriter.append(";");
            csvWriter.append(telefono);
            csvWriter.append(";");
            csvWriter.append(saldo);
            csvWriter.append(";"); 
            csvWriter.append(valorAdministracion);
            csvWriter.append(";");
            csvWriter.append(idPropietario);
            csvWriter.append(";");
            csvWriter.append(String.valueOf(metrosCuadrados));
            csvWriter.append(";");
            csvWriter.append(estado);
            csvWriter.append(";");
            csvWriter.append(identificacion);
            csvWriter.append(";");
            csvWriter.append(tipo);          
            csvWriter.append("\n");
            csvWriter.flush();
        } catch (IOException ex) {
            throw new Exception("Error al registrar la casa.", ex);
        }
    }

    private List<Casa> casas;

    public GestionDatosCasa() {
        casas = new ArrayList<>();  // Inicialización
    }

    // Método para leer el archivo CSV
    public List<Casa> leerCSV(String rutaArchivo) {
     
        casas = new ArrayList<Casa>();
        String linea;
        try (BufferedReader br = new BufferedReader(new FileReader("casasHojasSecas.csv"))) {
            br.readLine();
            while ((linea = br.readLine()) != null) {
                
                // Separar por punto y coma
                String[] valores = linea.split(";", -1);
                
                String direccion = valores[0];
                String telefono = valores[1];
                String saldo = valores[2];
                String valorAdministracion = valores[3];
                String idPropietario = valores[4];         
                String metrosCuadrados = valores[5];
                String estado = valores[6];
                String identificacion = valores[7];
                String tipo = valores[8]; 
                
                Casa casa = new Casa(direccion, telefono, saldo, valorAdministracion, idPropietario, metrosCuadrados, estado, identificacion, tipo);
                // Agregar el casa a la lista
                casas.add(casa);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return casas;
    }

    public List<Casa> getCasas() {
        return casas;
    }
    
    public Casa buscarID(String identificacion) {
        for (Casa casa : casas) {

            if (casa.getIdentificacion().equals(identificacion)) {
                return casa;  // Casa encontrado
            }
        }
        return null;  // Casa no encontrado
    }
        
    public boolean actualizarCasa(String identificacion, Casa nuevosDatos) {
        
        boolean actualizado = false;
        
        for (Casa casa : casas) {
            if (casa.getIdentificacion().equals(identificacion)) {
                // Actualizar los atributos de la casa
                casa.setDireccion(nuevosDatos.getDireccion());
                casa.setTelefono(nuevosDatos.getTelefono());
                casa.setSaldo(nuevosDatos.getSaldo());
                casa.setValorAdministracion(nuevosDatos.getValorAdministracion());
                casa.setIdPropietario(nuevosDatos.getIdPropietario());
                casa.setMetrosCuadrados(nuevosDatos.getMetrosCuadrados());
                casa.setEstado(nuevosDatos.getEstado());
                casa.setIdentificacion(nuevosDatos.getIdentificacion());
                casa.setTipo(nuevosDatos.getTipo());
                actualizado = true;  // Casa actualizado
            }
        }
        return actualizado;  // Casa no encontrado
    }
    
    public void guardarEnCSV(String rutaArchivo) {
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            // Escribir encabezado (si es necesario)            
                bw.write("Direccion;Telefono;Saldo;ValorAdministracion;IdPropietario;MetrosCuadrados;Estado;Identificacion;Tipo\n");
                // Escribir los datos de cada casa
                for (Casa casa : casas) {
                    bw.write(String.join(";", 
                        casa.getDireccion(),
                        casa.getTelefono(),
                        casa.getSaldo(),
                        casa.getValorAdministracion(),
                        casa.getIdPropietario(),
                        casa.getMetrosCuadrados(),                      
                        casa.getEstado(),
                        casa.getIdentificacion(),
                        casa.getTipo()) + "\n");
                }
            } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Casa buscarConId(String id) {
  
        for (Casa casa : casas) {
            if(casa.getIdentificacion().equals(id)){             
                return casa;  // Casa encontrado                
            }
        }return null;  // Casa no encontrado
    }
    
    public void eliminarCasa(String id) {
       
        Casa casaAEliminar = buscarConId(id); // Buscar al casa

        if (casaAEliminar != null) {
            casas.remove(casaAEliminar); // Eliminar el casa encontrado

            guardarEnCSV("casasHojasSecas.csv"); // Guardar cambios en el archivo CSV
        }
    }    
}
