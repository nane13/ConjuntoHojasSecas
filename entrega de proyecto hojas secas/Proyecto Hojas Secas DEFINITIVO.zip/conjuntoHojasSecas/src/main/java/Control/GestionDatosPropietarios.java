/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import Modelo.Propietario;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author nanet
 */
public class GestionDatosPropietarios {

    public void registrarPropietario() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
    // Método para leer los datos y guardarlos en un archivo CSV
    public void registrarPropietario(String idCasa, String oficio, String profesion, String nombre, String telefono, String correo, String id) throws Exception {

        // Crear el archivo CSV
        try (FileWriter csvWriter = new FileWriter("propietariosHojasSecas.csv", true)) {
            csvWriter.append(idCasa);
            csvWriter.append(";");
            csvWriter.append(oficio);
            csvWriter.append(";");
            csvWriter.append(profesion);
            csvWriter.append(";");
            csvWriter.append(nombre);
            csvWriter.append(";");
            csvWriter.append(telefono);
            csvWriter.append(";");
            csvWriter.append(correo);
            csvWriter.append(";");
            csvWriter.append(id);
            csvWriter.append("\n");
            csvWriter.flush();
        } catch (IOException ex) {
            throw new Exception("Error al registrar el propietario.", ex);
        }
    }
    private List<Propietario> propietarios;

    public GestionDatosPropietarios() {
        propietarios = new ArrayList<>();  // Inicialización
    }

    // Método para leer el archivo CSV
    public List<Propietario> leerCSV(String rutaArchivo) {
     
        propietarios = new ArrayList<Propietario>();
        String linea;
        try (BufferedReader br = new BufferedReader(new FileReader("propietariosHojasSecas.csv"))) {
            br.readLine();
            while ((linea = br.readLine()) != null) {
                
                // Separar por punto y coma
                String[] valores = linea.split(";", -1);
                
                String idCasa = valores[0];
                String oficio = valores[1];
                String profesion = valores[2];
                String nombre = valores[3];
                String telefono = valores[4];
                String correo = valores[5];
                String id = valores[6];          
                
                Propietario propietario = new Propietario(idCasa, oficio, profesion, nombre, telefono, correo, id);
                // Agregar el propietario a la lista
                propietarios.add(propietario);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return propietarios;
    }

    public List<Propietario> getPropietarios() {
        return propietarios;
    }
    
    public Propietario buscarID(String id) {
        for (Propietario propietario : propietarios) {

            if (propietario.getId().equals(id)) {
                return propietario;  // Propietario encontrado
            }
        }
        return null;  // Propietario no encontrado
    }
        
    public boolean actualizarPropietario(String id, Propietario nuevosDatos) {
        
        boolean actualizado = false;
        
        for (Propietario propietario : propietarios) {
            if (propietario.getId().equals(id)) {
                // Actualizar los atributos del propietario
                propietario.setIdCasa(nuevosDatos.getIdCasa());
                propietario.setOficio(nuevosDatos.getOficio());
                propietario.setProfesion(nuevosDatos.getProfesion());
                propietario.setNombre(nuevosDatos.getNombre());
                propietario.setTelefono(nuevosDatos.getTelefono());
                propietario.setCorreo(nuevosDatos.getCorreo());              
                propietario.setId(nuevosDatos.getId());
  
                actualizado = true;  // Propietario actualizado
            }
        }
        return actualizado;  // Propietario no encontrado
    }
    
    public void guardarEnCSV(String rutaArchivo) {
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            // Escribir encabezado (si es necesario)
            bw.write("IdCasa;Oficio;Profesion;Nombre;Telefono;Correo;Id\n");

            // Escribir los datos de cada propietario
            for (Propietario propietario : propietarios) {
                bw.write(String.join(";", 
                    propietario.getIdCasa(),
                    propietario.getOficio(),
                    propietario.getProfesion(),
                    propietario.getNombre(),
                    propietario.getTelefono(),
                    propietario.getCorreo(),
                    propietario.getId()) + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Propietario buscarConId(String id) {
  
        for (Propietario propietario : propietarios) {
            if(propietario.getId().equals(id)){             
                return propietario;  // Propietario encontrado                
            }
        }return null;  // Propietario no encontrado
    }
    
    public void eliminarPropietario(String id) {
       
        Propietario propietarioAEliminar = buscarConId(id); // Buscar al propietario

        if (propietarioAEliminar != null) {
            propietarios.remove(propietarioAEliminar); // Eliminar el propietario encontrado

            guardarEnCSV("propietariosHojasSecas.csv"); // Guardar cambios en el archivo CSV
        }
    }    
}
