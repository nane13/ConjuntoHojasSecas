/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import Modelo.Multa;
import com.google.gson.Gson;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class GestionDatosMulta {
    private static GestionDatosMulta instancia;
    private final List<Multa> multas;

    public GestionDatosMulta() {
        multas = new ArrayList<>();
    }
    
    public static GestionDatosMulta getInstance() {
        if (instancia == null) {
            instancia = new GestionDatosMulta();
        }
        return instancia;
    }
    
    public void agregarMulta(Multa multa) {
        multas.add(multa);
    }

    public Multa buscarPorId(String identificacion) {
        for (Multa multa : multas) {
            if (multa.getIdentificacion().equals(identificacion)) {
                return multa; // Multa encontrada
            }
        }
        return null; // Multa no encontrada
    }
    public void guardarMultaConPlantilla(Multa multa, String rutaArchivo) throws IOException {
        Gson gson = new Gson();
        
        String descripcion = String.format(
            "El conjunto residencial Hojas Cafes genera la multa con identificación %s en la fecha %s con las siguientes especificaciones: " +
            "Fecha del evento: %s, propiedad: %s, persona multada: %s. " +
            "Descripción del evento: %s, evento: %s, valor de la multa: %s, fecha máxima de pago: %s. " +
            "Observaciones: %s.",
            multa.getIdentificacion(),
            multa.getFechaEmision(),
            multa.getFechaEventoMulta(),
            multa.getPropiedad(),
            multa.getPersonaMultada(),
            multa.getDescripcionEvento(),
            multa.getEvento(),
            multa.getValorMulta(),
            multa.getFechaMaxPago(),
            multa.getObservacion()
        );

        Map<String, Object> datosMulta = new HashMap<>();
        datosMulta.put("identificacion", multa.getIdentificacion());
        datosMulta.put("fechaEmision", multa.getFechaEmision());
        datosMulta.put("fechaEventoMulta", multa.getFechaEventoMulta());
        datosMulta.put("idPropiedad", multa.getPropiedad());
        datosMulta.put("personaMultada", multa.getPersonaMultada());
        datosMulta.put("descripcionEvento", multa.getDescripcionEvento());
        datosMulta.put("evento", multa.getEvento());
        datosMulta.put("valorMulta", multa.getValorMulta());
        datosMulta.put("fechaMaxPago", multa.getFechaMaxPago());
        datosMulta.put("observacion", multa.getObservacion());
        datosMulta.put("descripcion", descripcion); 

        String json = gson.toJson(datosMulta);

        try (FileWriter writer = new FileWriter(rutaArchivo)) {
            writer.write(json);
            writer.flush();
        } catch (IOException e) {
            throw new IOException("Error al guardar la multa como JSON.", e);
        }
    }
}