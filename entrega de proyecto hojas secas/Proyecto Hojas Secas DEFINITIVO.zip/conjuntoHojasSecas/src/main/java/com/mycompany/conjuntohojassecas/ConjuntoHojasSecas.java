/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.conjuntohojassecas;
import Vista.InicioSesion;
/**
 *
 * @author nanet
 */
public class ConjuntoHojasSecas {

    public static void main(String[] args) {
        new InicioSesion().setVisible(true);
    }
}
